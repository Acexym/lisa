<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:49:"E:\phpStudy2016\WWW\tpk\addons\guanggao\info.html";i:1563358410;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		 <article class="excerpt-minic excerpt-minic-index">
 	<div>广告</div>
 	 </article>
	</body>
</html>
