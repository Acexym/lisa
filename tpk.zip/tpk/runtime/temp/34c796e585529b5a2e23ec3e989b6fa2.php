<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:72:"E:\phpStudy2016\WWW\tpk\public/../application/blog\view\article\add.html";i:1541600902;s:57:"E:\phpStudy2016\WWW\tpk\application\blog\view\layout.html";i:1563848517;}*/ ?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>明哥博客读者墙</title>
<link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/nprogress.css">
<link rel="stylesheet" type="text/css" href="/static/common/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/style.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/font-awesome.min.css">
<link rel="apple-touch-icon-precomposed" href="/static/index/images/icon/icon.png">
<link rel="shortcut icon" href="/static/index/images/icon/favicon.ico">
<script src="/static/index/js/jquery-2.1.4.min.js"></script>
<script src="/static/common/layer/layer.js"></script>
<script src="/static/common/layui/layui.all.js"></script>

<!--[if gte IE 9]>
  <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <script src="js/html5shiv.min.js" type="text/javascript"></script>
  <script src="js/respond.min.js" type="text/javascript"></script>
  <script src="js/selectivizr-min.js" type="text/javascript"></script>
<![endif]-->
<!--[if lt IE 9]>
  <script>window.location.href='upgrade-browser.html';</script>
<![endif]-->
	<style>
		.pagemenu>li>a{background: #EEE;text-decoration: none;boder:none;height:40px;margin: 0;}
		.pagemenu li ul li{
			
		}
		.pagemenu li ul li a{font-size:.8em;padding-left:25px;}
	</style>
</head>

<body class="user-select">
<header class="header">
  <nav class="navbar navbar-default" id="navbar">
    <div class="container">
      <div class="header-topbar hidden-xs link-border">
        <ul class="site-nav topmenu">
          <li><a href="tags.html">标签云</a></li>
          <li><a href="links.html" rel="nofollow">友情链接</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" rel="nofollow">关注本站 <span class="caret"></span></a>
            <ul class="dropdown-menu header-topbar-dropdown-menu">
              <li><a data-toggle="modal" data-target="#WeChat" rel="nofollow"><i class="fa fa-weixin"></i> 微信</a></li>
              <li><a href="#" rel="nofollow"><i class="fa fa-weibo"></i> 微博</a></li>
            </ul>
          </li>
        </ul>
  
                    <?php if(\think\Cookie::get('name') == null): ?>
                    <a data-toggle="modal" data-target="#loginModal" class="login" rel="nofollow">Hi,请登录</a>&nbsp;&nbsp;<a href="javascript:;" class="register" rel="nofollow">我要注册</a>&nbsp;&nbsp;<a href="" rel="nofollow">找回密码</a>
                    <?php else: ?>
                    [<?php echo decrypt(\think\Cookie::get('name'),SALT); ?>]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>  <a href='<?php echo url("blog/index/index"); ?>'>个人中心</a>
                    <?php endif; ?>
              &nbsp;&nbsp;<a href="javascript:;" class="register" rel="nofollow">我要注册</a>&nbsp;&nbsp;<a href="" rel="nofollow">找回密码</a> </div>
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar" aria-expanded="false"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <h1 class="logo hvr-bounce-in"><a href="" title=""><img src="images/logo.png" alt="" style="display:none;">小佳是我的</a></h1>
      </div>
      <div class="collapse navbar-collapse" id="header-navbar">
        <ul class="nav navbar-nav navbar-right">
          <li class="hidden-index active"><a data-cont="明哥课堂" href="index.html">首页</a></li>
          <li><a href="category.html">后端技术</a></li>
		  <li><a href="category.html">前端技术</a></li>
		  <li><a href="category.html">Linux</a></li>
		  <li><a href="category.html">视频教程</a></li>
          <li><a href="category.html">关于我们</a></li>
        </ul>
       <form class="navbar-form visible-xs" action="/Search" method="post">
          <div class="input-group">
            <input type="text" name="keyword" class="form-control" placeholder="请输入关键字" maxlength="20" autocomplete="off">
            <span class="input-group-btn">
            <button class="btn btn-default btn-search" name="search" type="submit">搜索</button>
            </span> </div>
        </form>
      </div>
    </div>
  </nav>
</header>
<section class="container container-page">
  <div class="pageside">
    <div class="pagemenus">
      <ul class="pagemenu">
        <li><a href="javascript:;">个人资料</a>
		  <ul>
			<li><a href="<?php echo url('blog/index/index'); ?>">博客管理</a></li>
			<li><a href="<?php echo url('blog/index/person'); ?>">详细资料</a></li>
			<li><a href="<?php echo url('blog/index/setpasswd'); ?>">密码修改</a></li>
		  </ul>
		</li>
        <li><a href="javascript:;">博文管理</a>
		  <ul>
			<li><a href="<?php echo url('blog/blogcate/lst'); ?>">博文列表</a></li>
			<li><a href="<?php echo url('blog/article/lst'); ?>">添加博文</a></li>
		  </ul>
		  </li>
        <li><a href="javascript:;">相册管理</a>
		  <ul>
			<li><a href="<?php echo url('blog/pics/lst'); ?>">图片列表</a></li>
			<li><a href="<?php echo url('blog/pics/add'); ?>">添加图片</a></li>
			<li><a href="<?php echo url('blog/picscate/lst'); ?>">相册列表</a></li>
		  </ul>
		</li>
		<li><a href="javascript:;">插件管理</a><ul>
      <?php if(is_array($addonmenu) || $addonmenu instanceof \think\Collection || $addonmenu instanceof \think\Paginator): $i = 0; $__LIST__ = $addonmenu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$m): $mod = ($i % 2 );++$i;?>
      <li><a href="<?php echo $m['url']; ?>"><?php echo $m['name']; ?></a></li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
     </ul></li>
		<li><a href="">友情连接</a></li>
      </ul>
    </div>
  </div>
  <div class="content">
   
<header class="article-header" style="padding-top:0px;padding-bottom: 15px;">
    <h1 class="article-title">添加博文</h1>
</header>
<div class="readers">
    <form class="form-horizontal" method="post" action="" onsubmit="return checkform();">

        <div class="form-group">
            <label for="cid" class="col-sm-2 control-label">分类</label>
            <div class="col-sm-10">
                <select class="form-control" name="cid" id="cid">
                    <?php if(is_array($catelist) || $catelist instanceof \think\Collection || $catelist instanceof \think\Paginator): $i = 0; $__LIST__ = $catelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <option value="<?php echo $vo['cid']; ?>"><?php echo $vo['name']; ?></option>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">标题</label>
            <div class="col-sm-10">
                <input type="text" name="title" class="form-control myinput" id="title" placeholder="标题">
            </div>
        </div>
        <div class="form-group">
            <label for="keyword" class="col-sm-2 control-label">关键字</label>
            <div class="col-sm-10">
                <input type="text" name="keyword" value="" class="form-control myinput" id="keyword" placeholder="关键字">
            </div>
        </div>
        <div class="form-group">
            <label for="desc" class="col-sm-2 control-label">描述</label>
            <div class="col-sm-10">
                <input type="text" name="desc" value="" class="form-control myinput" id="desc" placeholder="描述">
            </div>
        </div>
        <div class="form-group">
            <label for="remark" class="col-sm-2 control-label">摘要</label>
            <div class="col-sm-10">
                <input type="text" name="remark" value="" class="form-control myinput" id="remark" placeholder="摘要">
            </div>
        </div>
        <div class="form-group">
            <label for="source" class="col-sm-2 control-label">来源</label>
            <div class="col-sm-10">
                <input type="text" name="source" value="原创" class="form-control myinput" id="source" placeholder="来源">
            </div>
        </div>
        <div class="form-group">
            <label for="pic" class="col-sm-2 control-label">栏目图片</label>
            <div class="col-sm-10">
                <button type="button" class="layui-btn" id="myupload">
                    <i class="layui-icon">&#xe67c;</i>上传图片
                </button>
                <input type="text" name="pic" value="" class="form-control myinput" id="pic" placeholder="栏目图片">
            </div>
        </div>
        <div class="form-group">
            <label for="container" class="col-sm-2 control-label">详情</label>
            <div class="col-sm-10">
                <!--<textarea name="content" id="container" class="form-control" rows="8"></textarea>-->
                <script id="container" name="content" type="text/plain">

                </script>
            </div>
        </div>
        <div class="form-group">
            <label for="pic" class="col-sm-2 control-label">是否显示</label>
            <div class="col-sm-10">
                <label class="checkbox-inline">
                    <input type="checkbox" id="isnominate" name="isnominate" value="1" checked="checked"> 是否推荐
                </label>
            </div>
        </div>
        <div class="form-group">
            <label for="istop" class="col-sm-2 control-label">是否置顶</label>
            <div class="col-sm-10">
                <label class="checkbox-inline">
                    <input type="checkbox" id="istop" name="istop" value="1"> 是否置顶
                </label>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default">保存</button>
            </div>
        </div>
        <div id="msg" style="color:red;"></div>
    </form>
</div>
<!-- 配置文件 -->
<script type="text/javascript" src="/static/common/ueditor/ueditor.config.js"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="/static/common/ueditor/ueditor.all.js"></script>
<script>
    //实例化编辑器
    var ue = UE.getEditor('container',{
        autoHeightEnabled: true,
        //常用配置项
        initialFrameWidth:null,//自适应宽度
    });
    //表单的前端验证
    function checkform() {
        var input=document.getElementsByClassName('myinput');
        var name=input[0].value.trim();
        if(title=="" || title ==null || title=="undefined"){
            var msg=document.getElementById("msg");
            msg.innerHTML="* 标题不能为空！";
            return false;
        }else{
            return true;
        }

    }
    //图片上传
    // layui.use('upload', function(){
    //     var upload = layui.upload;
    //     //执行实例
    //     var uploadInst = upload.render({
    //         elem: '#myupload' //绑定元素
    //         ,url: '<?php echo url("blog/Blogcate/upimg"); ?>' //上传接口
    //         ,field:'upimg'
    //         ,done: function(res){
    //             //上传完毕回调
    //             layer.msg(res.msg,{time:2000},function () {
    //                 if(res.code==1){
    //                     $("#pic").val("uploads\\"+res.src);
    //                 }
    //             })
    //         }
    //         ,error: function(){
    //             //请求异常回调
    //         }
    //     });
    // });
    //自动upload组件
    var upload = layui.upload;
    //执行实例
    var uploadInst = upload.render({
        elem: '#myupload' //绑定元素
        ,url: '<?php echo url("blog/Article/upimg"); ?>' //上传接口
        ,field:'upimg'
        ,done: function(res){
            //上传完毕回调
            layer.msg(res.msg,{time:2000},function () {
                if(res.code==1){
                    $("#pic").val("uploads\\"+res.src);
                }
            })
        }
        ,error: function(){
            //请求异常回调
        }
    });
</script>
  </div>
</section>
<footer class="footer">
  <div class="container">
    <p>&copy; 2018 <a href="">yfketang.com</a> &nbsp; <a href="#" target="_blank" rel="nofollow">豫ICP备0000000-1</a> &nbsp; &nbsp; <a href="http://www.yfketang.cn/" target="_blank">明哥课堂</a></p>
  </div>
  <div id="gotop"><a class="gotop"></a></div>
</footer>
<!--微信二维码模态框-->
<div class="modal fade user-select" id="WeChat" tabindex="-1" role="dialog" aria-labelledby="WeChatModalLabel">
  <div class="modal-dialog" role="document" style="margin-top:120px;width:280px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="WeChatModalLabel" style="cursor:default;">微信扫一扫</h4>
      </div>
      <div class="modal-body" style="text-align:center"> <img src="images/weixin.jpg" alt="" style="cursor:pointer"/> </div>
    </div>
  </div>
</div>

<!--右键菜单列表-->
<div id="rightClickMenu">
  <ul class="list-group rightClickMenuList">
    <li class="list-group-item disabled">欢迎访问明哥课堂博客</li>
    <li class="list-group-item"><span>IP：</span>172.16.10.129</li>
    <li class="list-group-item"><span>教程：</span><a href="http://www.yfketang.cn">www.blog.cn</a></li>
  </ul>
</div>
<script src="/static/index/js/bootstrap.min.js"></script> 
<!--<script src="js/jquery.ias.js"></script> -->
<script src="/static/index/js/scripts.js"></script>
	<script>
		$('#logo').on('click',function(){
			$('input[type="file"]').click();
		});
		$('#uploadfile').on('click',function(){
			$('input[type="file"]').click();
		});
		$('#uploadfile').on('click',function(){
			$('input[type="file"]').click();
		});
	
	</script>
</body>
</html>