<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"E:\phpStudy2016\WWW\tpk\public/../application/index\view\index\index.html";i:1564039887;s:56:"E:\phpStudy2016\WWW\tpk\application\common\view\top.html";i:1564067267;}*/ ?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>多弗朗博客</title>
<link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/nprogress.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/style.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/font-awesome.min.css">
<link rel="apple-touch-icon-precomposed" href="images/icon/icon.png">
<link rel="shortcut icon" href="/static/index/images/icon/favicon.ico">
<script src="/static/index/js/jquery-2.1.4.min.js"></script>
<script src="/static/index/js/nprogress.js"></script>
<script src="/static/index/js/jquery.lazyload.min.js"></script>
<!--[if gte IE 9]>
  <script src="/static/index/js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <script src="/static/index/js/html5shiv.min.js" type="text/javascript"></script>
  <script src="/static/index/js/respond.min.js" type="text/javascript"></script>
  <script src="/static/index/js/selectivizr-min.js" type="text/javascript"></script>
<![endif]-->
<!--[if lt IE 9]>
  <script>window.location.href='upgrade-browser.html';</script>
<![endif]-->
</head>

<body class="user-select">
<header class="header">
    <nav class="navbar navbar-default" id="navbar">
        <div class="container">
            <div class="header-topbar hidden-xs link-border">
                <ul class="site-nav topmenu">
                    <li><a href="">标签云</a></li>
                    <li><a href="links.html" rel="nofollow">友情链接</a></li>
                    <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" rel="nofollow">关注本站 <span class="caret"></span></a>
                        <ul class="dropdown-menu header-topbar-dropdown-menu">
                            <li><a data-toggle="modal" data-target="#WeChat" rel="nofollow"><i class="fa fa-weixin"></i> 微信</a></li>
                            <li><a href="#" rel="nofollow"><i class="fa fa-weibo"></i> 微博</a></li>
                        </ul>
                    </li>
                </ul>
                <div id="loginstatus">
                    <?php if(\think\Cookie::get('name') == null): ?>
                    <a data-toggle="modal" data-target="#loginModal" class="login" rel="nofollow">Hi,请登录</a>&nbsp;&nbsp;<a href="javascript:;" class="register" rel="nofollow">我要注册</a>&nbsp;&nbsp;<a href="" rel="nofollow">找回密码</a>
                    <?php else: ?>
                    [<?php echo decrypt(\think\Cookie::get('name'),SALT); ?>]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>  <a href='<?php echo url("blog/index/index"); ?>'>个人中心</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar" aria-expanded="false"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <h1 class="logo hvr-bounce-in"><a href="" title=""><img src="/static/index/images/logo.png" alt="" style="display:none;">小佳我喜欢你</a></h1>
            </div>
            <div class="collapse navbar-collapse" id="header-navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden-index active"><a data-cont="易风课堂" href="/">首页</a></li>
                    <li><a href="category.html">博文</a></li>
                    <li><a href="category.html">相册</a></li>
                    <li><a href="<?php echo url('admin/login/index'); ?>">后台中心</a></li>
                </ul>
                <form class="navbar-form visible-xs" action="/Search" method="post">
                    <div class="input-group">
                        <input type="text" name="keyword" class="form-control" placeholder="请输入关键字" maxlength="20" autocomplete="off">
                        <span class="input-group-btn">
            <button class="btn btn-default btn-search" name="search" type="submit">搜索</button>
            </span> </div>
                </form>
            </div>
        </div>
    </nav>
</header>
<script src="/static/common/layui/layui.all.js"></script>
<script>
    $(function(){
        $("#myloginbtn").on('click',function(){
            var data=$("#myform").serialize();
            $.post("<?php echo url('index/Login/index'); ?>",data,function(res){
                if(res.code==1){
                    $('#loginModal').modal('hide')
                    $("#loginstatus").html("["+res.name+"]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>  <a href='<?php echo url("blog/index/index"); ?>'>个人中心</a>");
                    $("#centre").html("["+res.name+"]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>  <a href='<?php echo url("blog/index/index"); ?>'>个人中心</a>");
                    location.reload();
                }
               
            },'json');
            return false;
        });

    })
</script>
<section class="container">
  <div class="content-wrap">
    <div class="content">
      <div class="jumbotron">
        <h1>欢迎访问多弗朗博客</h1>
        <p>在这里可以看到前端技术，后端程序，网站内容管理系统等文章，还有我的程序人生！</p>
         
      </div>
      <div id="focusslide" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#focusslide" data-slide-to="0" class="active"></li>
          <li data-target="#focusslide" data-slide-to="1"></li>
          <li data-target="#focusslide" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <div class="item active"> <a href="" target="_blank"><img src="/static/index/images/banner/004.png" alt="" class="img-responsive"></a>       
          </div>
          <div class="item"> <a href="" target="_blank"><img src="/static/index/images/banner/005.png" alt="" class="img-responsive"></a>       
          </div>
          <div class="item"> <a href="" target="_blank"><img src="/static/index/images/banner/003.png" alt="" class="img-responsive"></a>          
          </div>
        </div>
        <a class="left carousel-control" href="#focusslide" role="button" data-slide="prev" rel="nofollow"> <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> <span class="sr-only">上一个</span> </a> <a class="right carousel-control" href="#focusslide" role="button" data-slide="next" rel="nofollow"> <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span> <span class="sr-only">下一个</span> </a> </div>
<div><?php echo hook('gghook'); ?></div>
      <article class="excerpt-minic excerpt-minic-index">
        <?php if(is_array($tuijian) || $tuijian instanceof \think\Collection || $tuijian instanceof \think\Paginator): $i = 0; $__LIST__ = $tuijian;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <h2><span class="red">【今日推荐】</span><a href="<?php echo url('index/Article/show',['id'=>$vo['aid']]); ?>" title=""><?php echo $vo['title']; ?></a></h2>
        <p class="note"><?php echo $vo['remark']; ?>...</p>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </article>
      <div class="title">
        <h3>最新发布</h3>
     
        <div class="more">
          <?php if(is_array($blogcates) || $blogcates instanceof \think\Collection || $blogcates instanceof \think\Paginator): $i = 0; $__LIST__ = $blogcates;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <a href="<?php echo url('index/Article/index',['cid'=>$vo['cid']]); ?>"><?php echo $vo['name']; ?></a>
          <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
      </div>
      <?php if(is_array($newblogs) || $newblogs instanceof \think\Collection || $newblogs instanceof \think\Paginator): $i = 0; $__LIST__ = $newblogs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
	 <article class="excerpt excerpt-3"><a class="focus" href="<?php echo url('index/Article/show',['id'=>$vo['aid']]); ?>" title=""><img class="thumb" data-original="/<?php echo $vo['pic']; ?>" src="/static/index/images/excerpt.jpg" alt=""></a>
        <header><a class="cat" href="<?php echo url('index/Article/index',['cid'=>$vo['cid']]); ?>"><?php echo getcatename($vo['cid']); ?><i></i></a>
          <h2><a href="<?php echo url('index/Article/show',['id'=>$vo['aid']]); ?>" title=""><?php echo $vo['title']; ?></a></h2>
        </header>
        <p class="meta">
          <time class="time"><i class="glyphicon glyphicon-time"></i> <?php echo date("Y/m/d H:i:s",$vo['addtime']); ?></time>
          <span class="views"><i class="glyphicon glyphicon-eye-open"></i> 共<?php echo $vo['views']; ?>人围观</span> <a class="comment" href="article.html#comment"><i class="glyphicon glyphicon-comment"></i> 10000</a></p>
        <p class="note"><?php echo $vo['remark']; ?>... </p>
      </article>
      <?php endforeach; endif; else: echo "" ;endif; ?>
      <!--<nav class="pagination">-->
        <!--<ul>-->
          <!--<li class="prev-page"></li>-->
          <!--<li class="active"><span>1</span></li>-->
          <!--<li><a href="?page=2">2</a></li>-->
          <!--<li class="next-page"><a href="?page=2">下一页</a></li>-->
          <!--<li><span>共 2 页</span></li>-->
        <!--</ul>-->
      <!--</nav>-->
    
     
    </div>
    	<div><?php echo hook('testhook'); ?></div>
    	
  </div>
  <aside class="sidebar">
    <div class="fixed">
      <div class="widget widget-tabs">
        <ul class="nav nav-tabs" role="tablist">
          <li role="presentation" class="active"><a href="#notice" aria-controls="notice" role="tab" data-toggle="tab">网站公告</a></li>
          <li role="presentation"><a href="#centre" aria-controls="centre" role="tab" data-toggle="tab">个人中心</a></li>
          <li role="presentation"><a href="#contact" aria-controls="contact" role="tab" data-toggle="tab">联系站长</a></li>
        </ul>
        <div class="tab-content">
          <div role="tabpanel" class="tab-pane notice active" id="notice">
            <ul>
              <li>
                <time datetime="2016-01-04">01-04</time>
                <a href="" target="_blank">欢迎访问明哥表白墙</a></li>
              <li>
                <time datetime="2016-01-04">01-04</time>
                <a target="_blank" href="">在这里可以看到前端技术，后端程序，网站内容管理系统等文章，还有我的程序人生！</a></li>
              <li>
                <time datetime="2016-01-04">01-04</time>
                <a target="_blank" href="">在这个小工具中最多可以调用五条</a></li>
            </ul>
          </div>
          <div role="tabpanel" class="tab-pane centre" id="centre">
            <?php if(\think\Cookie::get('name') == null): ?>
            <h4>需要登录才能进入个人中心</h4>
            <p> <a data-toggle="modal" data-target="#loginModal" class="btn btn-primary">立即登录</a> <a href="javascript:;" data-toggle="modal" data-target="#registerModal" class="btn btn-default">现在注册</a> </p>
            <?php else: ?>
            [<?php echo decrypt(\think\Cookie::get('name'),SALT); ?>]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>
            <?php endif; ?>
          </div>
          <div role="tabpanel" class="tab-pane contact" id="contact">
            <h2>Email:<br />
              <a href="mailto:576617109@qq.com" data-toggle="tooltip" data-placement="bottom" title="admin@ylsat.com">576617109@qq.com</a></h2>
          </div>
        </div>
      </div>
      <div class="widget widget_search">
        <form class="navbar-form" action="/Search" method="post">
          <div class="input-group">
            <input type="text" name="keyword" class="form-control" size="35" placeholder="请输入关键字" maxlength="15" autocomplete="off">
            <span class="input-group-btn">
            <button class="btn btn-default btn-search" name="search" type="submit">搜索</button>
            </span> </div>
        </form>
      </div>
    </div>
    <div class="widget widget_sentence">
      <h3>每日一句</h3>
      <div class="widget-sentence-content">
        <h4>2018年03月04日</h4>
        <p>ThinkPHP5.0快速开发博客系统</p>
      </div>
    </div>
    <div class="widget widget_hot">
      <h3>热门文章</h3>
      <ul>
        <?php if(is_array($hotblogs) || $hotblogs instanceof \think\Collection || $hotblogs instanceof \think\Paginator): $i = 0; $__LIST__ = $hotblogs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url('index/Article/show',['id'=>$vo['aid']]); ?>"><span class="thumbnail"><img class="thumb" data-original="/<?php echo $vo['pic']; ?>" src="/<?php echo $vo['pic']; ?>" alt=""></span><span class="text"><?php echo $vo['title']; ?></span><span class="muted"><i class="glyphicon glyphicon-time"></i> <?php echo date("Y/m/d H:i:s",$vo['addtime']); ?> </span><span class="muted"><i class="glyphicon glyphicon-eye-open"></i> <?php echo $vo['views']; ?></span></a></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>
    </div>
  </aside>
</section>
<!--插件扩展-->

<footer class="footer">
  <div class="container">
    <p>&copy; 2018 <a href="">yfketang.com</a> &nbsp; <a href="#" target="_blank" rel="nofollow">豫ICP备0000000-1</a> &nbsp; &nbsp; <a href="http://www.yfketang.cn/" target="_blank">明哥</a></p>
  </div>
  <div id="gotop"><a class="gotop"></a></div>
</footer>
<!--微信二维码模态框-->
<div class="modal fade user-select" id="WeChat" tabindex="-1" role="dialog" aria-labelledby="WeChatModalLabel">
  <div class="modal-dialog" role="document" style="margin-top:120px;max-width:280px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="WeChatModalLabel" style="cursor:default;">微信扫一扫</h4>
      </div>
      <div class="modal-body" style="text-align:center"> <img src="/static/index/images/weixin.jpg" alt="" style="cursor:pointer"/> </div>
    </div>
  </div>
</div>

<!--登录注册模态框-->
<div class="modal fade user-select" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="myform">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="loginModalLabel">登录</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="loginModalUserNmae">用户名</label>
            <input type="text" class="form-control" name="account" id="loginModalUserNmae" placeholder="请输入用户名" autofocus maxlength="15" autocomplete="off" required>
          </div>
          <div class="form-group">
            <label for="loginModalUserPwd">密码</label>
            <input type="password" class="form-control" name="passwd" id="loginModalUserPwd" placeholder="请输入密码" maxlength="18" autocomplete="off" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
          <button type="submit" class="btn btn-primary" id="myloginbtn">登录</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--注册模态框-->
<div class="modal fade user-select" id="registerModal" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="/Admin/Index/login" method="post">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="registerModalLabel">用户注册</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="registerModalUserNmae">用户名（用户名必须是邮箱）</label>
            <input type="text" class="form-control" id="registerModalUserNmae" placeholder="请输入用户名" autofocus maxlength="15" autocomplete="off" required>
          </div>
          <div class="form-group">
            <label for="registerModalUserPwd">密码</label>
            <input type="password" class="form-control" id="registerModalUserPwd" placeholder="请输入密码" maxlength="18" autocomplete="off" required>
          </div>
		  <div class="form-group">
            <label for="registerModalUserPwd">确认密码</label>
            <input type="password" class="form-control" id="registerModalUserPwd" placeholder="请输入确认密码" maxlength="18" autocomplete="off" required>
          </div>
		  <div class="form-group">
            <label for="registerModalUserPwd">验证码</label>
            <input type="password" class="form-control" id="registerModalUserPwd" placeholder="请输入验证码" maxlength="18" autocomplete="off" required style="width:105px;">
          </div>
        </div>
        
      
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
          <button type="submit" class="btn btn-primary">注册</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--右键菜单列表-->
<div id="rightClickMenu">
  <ul class="list-group rightClickMenuList">
    <li class="list-group-item disabled">欢迎访问多弗朗博客</li>
    <li class="list-group-item"><span>IP：</span>172.16.10.129</li>
    <li class="list-group-item"><span>教程：</span><a href="http://www.yfketang.cn">www.mingG.cn</a></li>
  </ul>
</div>
<script src="/static/index/js/bootstrap.min.js"></script>
<script src="/static/index/js/jquery.ias.js"></script>
<script src="/static/index/js/scripts.js"></script>
</body>
</html>