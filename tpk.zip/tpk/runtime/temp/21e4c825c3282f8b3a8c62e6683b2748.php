<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\logs\index.html";i:1541600902;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>日志管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/common/js/jquery.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">日志管理</a>
        <a>
          <cite>日志列表</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <xblock>
        <button class="layui-btn layui-btn-danger" onclick="delAll()"><i class="layui-icon"></i>批量删除</button>
        <span class="x-right" style="line-height:40px">共有数据：<?php echo count($list); ?> 条</span>
      </xblock>
      <table class="layui-table"  lay-filter="mytable">
        <thead>
          <tr>
            <th lay-data="{type:'checkbox', width:60}">
            </th>
            <th lay-data="{field:'id', width:50}">ID</th>
            <th lay-data="{field:'account',width:100}">操作员</th>
            <th lay-data="{field:'url'}">节点</th>
            <th lay-data="{field:'description', width:200}">描述</th>
            <th lay-data="{field:'operate_time', width:180}">操作时间</th>
            <th lay-data="{field:'operate_ip', width:150}">操作ip</th>
            <th lay-data="{field:'caozuo', width:200}">操作</th>
        </thead>
        <tbody>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <tr>
            <td></td>
            <td><?php echo $vo['id']; ?></td>
            <td><?php echo $vo['account']; ?></td>
            <td><?php echo $vo['url']; ?></td>
            <td><?php echo $vo['description']; ?></td>
            <td><?php echo date("Y/m/d H:i:s",$vo['operate_time']); ?></td>
            <td><?php echo $vo['operate_ip']; ?></td>
            <td class="td-manage">
              <a href="<?php echo url('admin/Logs/del',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-normal layui-btn-xs">删除</a>
            </td>
          </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
      </table>
    </div>
    <script>
      var table;
      layui.use('table', function(){
          table= layui.table;

          //转换静态表格
          table.init('mytable', {
              id:"mytable"
              ,height: 600 //设置高度
              ,limit: 1 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
              //支持所有基础参数
              ,page:{
                  count:<?php echo count($list); ?>
                  ,limit:30

              }
          });
      });
      layui.use('upload', function(){
          var upload = layui.upload;

          //执行实例
          var index;
          var uploadInst = upload.render({
              elem: '#upfile' //绑定元素
              ,url: '<?php echo url("admin/Addons/lxinstall"); ?>' //上传接口
              ,field:'addons'
              ,exts:'zip'
              ,before:function(){
                  index = layer.load();
              }
              ,done: function(res){
                  //上传完毕回调
                  layer.close(index);
                  layer.msg(res.msg,{time:1000},function(){
                      if(res.code==1){
                          location.reload();
                      }
                  });
              }
              ,error: function(){
                  //请求异常回调
              }
          });
      });
    </script>

  </body>

</html>