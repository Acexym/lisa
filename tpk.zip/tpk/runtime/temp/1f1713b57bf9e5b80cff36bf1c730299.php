<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"E:\phpStudy2016\WWW\tpk\public/../application/blog\view\blogcate\lst.html";i:1562817634;s:57:"E:\phpStudy2016\WWW\tpk\application\blog\view\layout.html";i:1564047730;}*/ ?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>明哥博客读者墙</title>
<link rel="stylesheet" type="text/css" href="/static/index/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/nprogress.css">
<link rel="stylesheet" type="text/css" href="/static/common/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/style.css">
<link rel="stylesheet" type="text/css" href="/static/index/css/font-awesome.min.css">
<link rel="apple-touch-icon-precomposed" href="/static/index/images/icon/icon.png">
<link rel="shortcut icon" href="/static/index/images/icon/favicon.ico">
<script src="/static/index/js/jquery-2.1.4.min.js"></script>
<script src="/static/common/layer/layer.js"></script>
<script src="/static/common/layui/layui.all.js"></script>

<!--[if gte IE 9]>
  <script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
  <script src="js/html5shiv.min.js" type="text/javascript"></script>
  <script src="js/respond.min.js" type="text/javascript"></script>
  <script src="js/selectivizr-min.js" type="text/javascript"></script>
<![endif]-->
<!--[if lt IE 9]>
  <script>window.location.href='upgrade-browser.html';</script>
<![endif]-->
	<style>
		.pagemenu>li>a{background: #EEE;text-decoration: none;boder:none;height:40px;margin: 0;}
		.pagemenu li ul li{
			
		}
		.pagemenu li ul li a{font-size:.8em;padding-left:25px;}
	</style>
</head>

<body class="user-select">
<header class="header">
  <nav class="navbar navbar-default" id="navbar">
    <div class="container">
      <div class="header-topbar hidden-xs link-border">
        <ul class="site-nav topmenu">
          <li><a href="tags.html">标签云</a></li>
          <li><a href="links.html" rel="nofollow">友情链接</a></li>
          <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" rel="nofollow">关注本站 <span class="caret"></span></a>
            <ul class="dropdown-menu header-topbar-dropdown-menu">
              <li><a data-toggle="modal" data-target="#WeChat" rel="nofollow"><i class="fa fa-weixin"></i> 微信</a></li>
              <li><a href="#" rel="nofollow"><i class="fa fa-weibo"></i> 微博</a></li>
            </ul>
          </li>
        </ul>
  
                    <?php if(\think\Cookie::get('name') == null): ?>
                    <a data-toggle="modal" data-target="#loginModal" class="login" rel="nofollow">Hi,请登录</a>&nbsp;&nbsp;<a href="javascript:;" class="register" rel="nofollow">我要注册</a>&nbsp;&nbsp;<a href="" rel="nofollow">找回密码</a>
                    <?php else: ?>
                    [<?php echo decrypt(\think\Cookie::get('name'),SALT); ?>]已登录 <a href='<?php echo url("index/Login/goout"); ?>'>退出</a>  <a href='<?php echo url("blog/index/index"); ?>'>个人中心</a>
                    <?php endif; ?>
              &nbsp;&nbsp;<a href="javascript:;" class="register" rel="nofollow">我要注册</a>&nbsp;&nbsp;<a href="" rel="nofollow">找回密码</a> </div>
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header-navbar" aria-expanded="false"> <span class="sr-only"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        <h1 class="logo hvr-bounce-in"><a href="" title=""><img src="images/logo.png" alt="" style="display:none;">小佳是我的</a></h1>
      </div>
      <div class="collapse navbar-collapse" id="header-navbar">
        <ul class="nav navbar-nav navbar-right">
          <li class="hidden-index active"><a data-cont="明哥课堂" href="index.html">首页</a></li>
          <li><a href="<?php echo url('index/index/index'); ?>">我的博客</a></li>
		
		  <li><a href="category.html">Linux</a></li>
		  <li><a href="category.html">视频教程</a></li>
          <li><a href="category.html">关于我们</a></li>
        </ul>
       <form class="navbar-form visible-xs" action="/Search" method="post">
          <div class="input-group">
            <input type="text" name="keyword" class="form-control" placeholder="请输入关键字" maxlength="20" autocomplete="off">
            <span class="input-group-btn">
            <button class="btn btn-default btn-search" name="search" type="submit">搜索</button>
            </span> </div>
        </form>
      </div>
    </div>
  </nav>
</header>
<section class="container container-page">
  <div class="pageside">
    <div class="pagemenus">
      <ul class="pagemenu">
        <li><a href="javascript:;">个人资料</a>
		  <ul>
			<li><a href="<?php echo url('blog/index/index'); ?>">博客管理</a></li>
			<li><a href="<?php echo url('blog/index/person'); ?>">详细资料</a></li>
			<li><a href="<?php echo url('blog/index/setpasswd'); ?>">密码修改</a></li>
		  </ul>
		</li>
        <li><a href="javascript:;">博文管理</a>
		  <ul>
			<li><a href="<?php echo url('blog/blogcate/lst'); ?>">博文列表</a></li>
			<li><a href="<?php echo url('blog/article/lst'); ?>">添加博文</a></li>
		  </ul>
		  </li>
        <li><a href="javascript:;">相册管理</a>
		  <ul>
			<li><a href="<?php echo url('blog/pics/lst'); ?>">图片列表</a></li>
			<li><a href="<?php echo url('blog/pics/add'); ?>">添加图片</a></li>
			<li><a href="<?php echo url('blog/picscate/lst'); ?>">相册列表</a></li>
			<li><a href="<?php echo url('blog/pics/cate'); ?>">个人相册</a></li>
		  </ul>
		</li>
		<li><a href="javascript:;">插件管理</a><ul>
      <?php if(is_array($addonmenu) || $addonmenu instanceof \think\Collection || $addonmenu instanceof \think\Paginator): $i = 0; $__LIST__ = $addonmenu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$m): $mod = ($i % 2 );++$i;?>
      <li><a href="<?php echo $m['url']; ?>"><?php echo $m['name']; ?></a></li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
     </ul></li>
		<li><a href="">友情连接</a></li>
      </ul>
    </div>
  </div>
  <div class="content">
   
<style>
    .pagination{padding:0;}
</style>
<header class="article-header" style="padding-top:0px;padding-bottom: 15px;">
    <h1 class="article-title">博文分类列表</h1>
</header>
<div class="table-responsive">
    <a href="<?php echo url('blog/Blogcate/add'); ?>" class="btn btn-danger">添加分类</a>
    <table class="table table-bordered table-hover">
        <tr>
            <td class="">ID</td>
            <td class="">分类名称</td>
            <td class="" style="width: 85px;">排序</td>
            <td class="">操作</td>
        </tr>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

        <tr>
            <td class=""><?php echo $vo['cid']; ?></td>
            <td class=""><?php echo $vo['name']; ?></td>
            <td class="">
                <input type="text" data="<?php echo $vo['cid']; ?>" value="<?php echo $vo['sort']; ?>" olddata="<?php echo $vo['sort']; ?>" class="form-control inputsort" style="width: 80px;">
            </td>
            <td class=""><a href="<?php echo url('blog/Blogcate/edit',['cid'=>$vo['cid']]); ?>" class="btn btn-danger btn-xs btn-edit"><i class="glyphicon glyphicon-edit"></i> 编辑</a> <a href="javascript::" data="<?php echo $vo['cid']; ?>" class="btn btn-info btn-xs del"><i class="glyphicon glyphicon-trash"></i> 删除</a></td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
    <nav aria-label="...">
        <?php echo $list->render(); ?>
    </nav>
</div>
<script>
    $('.btn-edit').on('click',function () {
        var url=this.href;
        layer.open({
            type: 2,
            title: '栏目编辑',
            shadeClose: true,
            shade: 0.8,
            area: ['380px', '75%'],
            content:url  //iframe的url
        });
        return false;
    });
    //分类删除
    $(".del").on('click',function(){
        //this和$(this)的区别
        //获取栏目ID
        var cid=$(this).attr("data");

        //询问框
        layer.confirm('确定要删除吗？', {
            btn: ['删除','取消'] //按钮
        }, function(){
            $.ajax({
                type:"post",
                url:"<?php echo url('blog/Blogcate/del'); ?>",
                data:{id:cid},
                dataType:"json",
                success:function(res){
                    if(res.code==1){
                        layer.msg(res.msg,function(){
                            location.reload();
                        });
                    }else{
                        layer.msg(res.msg);
                    }
                }
            })
        }, function(){
        });
    })
    //排序
    $(".inputsort").blur(function () {
        var cid=$(this).attr("data");
        var sort=$(this).val();
        var oldsort=$(this).attr("olddata");
        if(sort==oldsort){
            return;
        }
        $.ajax({
            type:"post",
            url:"<?php echo url('blog/Blogcate/setsort'); ?>",
            data:{id:cid,sort:sort},
            dataType:"json",
            success:function(res){
                if(res.code==1){
                    layer.msg(res.msg,function(){
                        location.reload();
                    });
                }else{
                    layer.msg(res.msg);
                }
            }
        })
    });
</script>
  </div>
</section>
<footer class="footer">
  <div class="container">
    <p>&copy; 2018 <a href="">yfketang.com</a> &nbsp; <a href="#" target="_blank" rel="nofollow">豫ICP备0000000-1</a> &nbsp; &nbsp; <a href="http://www.yfketang.cn/" target="_blank">明哥课堂</a></p>
  </div>
  <div id="gotop"><a class="gotop"></a></div>
</footer>
<!--微信二维码模态框-->
<div class="modal fade user-select" id="WeChat" tabindex="-1" role="dialog" aria-labelledby="WeChatModalLabel">
  <div class="modal-dialog" role="document" style="margin-top:120px;width:280px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="WeChatModalLabel" style="cursor:default;">微信扫一扫</h4>
      </div>
      <div class="modal-body" style="text-align:center"> <img src="images/weixin.jpg" alt="" style="cursor:pointer"/> </div>
    </div>
  </div>
</div>

<!--右键菜单列表-->
<div id="rightClickMenu">
  <ul class="list-group rightClickMenuList">
    <li class="list-group-item disabled">欢迎访问明哥课堂博客</li>
    <li class="list-group-item"><span>IP：</span>172.16.10.129</li>
    <li class="list-group-item"><span>教程：</span><a href="http://www.yfketang.cn">www.blog.cn</a></li>
  </ul>
</div>
<script src="/static/index/js/bootstrap.min.js"></script> 
<!--<script src="js/jquery.ias.js"></script> -->
<script src="/static/index/js/scripts.js"></script>
	<script>
		$('#logo').on('click',function(){
			$('input[type="file"]').click();
		});
		$('#uploadfile').on('click',function(){
			$('input[type="file"]').click();
		});
		$('#uploadfile').on('click',function(){
			$('input[type="file"]').click();
		});
	
	</script>
</body>
</html>