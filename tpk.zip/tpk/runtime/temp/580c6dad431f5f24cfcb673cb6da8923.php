<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:45:"E:\phpStudy2016\WWW\tpk\addons\test\info.html";i:1563353980;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        .link{list-style: none;}
        .link li{float: left;padding:0 15px;text-align: center;}
    </style>
</head>
<body>
<div class="" style="width:1000px;margin:10px auto;border:1px solid red;overflow: hidden;">
    <h3>友情连接</h3>
    <ul class="link">
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
        <li><a href="<?php echo addon_url('test://Action/link'); ?>">测试</a></li>
    </ul>
</div>
</body>
</html>