<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:70:"E:\phpStudy2016\WWW\tpk\public/../application/blog\view\pics\cate.html";i:1564047338;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
        *{
            margin: 0;
            padding: 0;
            border: none;
            list-style: none;
        }

        html, body, ul{
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        #ps{
            position: relative;
        }

        #ps li{
            width: 250px;
         
            box-shadow: 0 0 10px #000;

            position: absolute;

            transition: all 1s;
        }

        #ps li.current{
            left: 50% !important;
            top: 50% !important;
            transform: rotate(0deg) translate(-50%, -50%) scale(1.5, 1.5) !important;
            z-index: 99;
        }
    </style>
</head>
<body>
	<form action="" method="post">
	
		 <?php if(is_array($pic) || $pic instanceof \think\Collection || $pic instanceof \think\Paginator): $i = 0; $__LIST__ = $pic;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
		<input type="hidden" class="srcs" value="<?php echo $vo['pic']; ?>"/>
		 <?php endforeach; endif; else: echo "" ;endif; ?>
	</form>
   <ul id="ps"></ul>
<script src="/static/blog/js/Underscore-min.js"></script>
<script src="/static/index/js/jquery-2.1.4.min.js"></script>
<script>
    window.onload = function () {
 	 var allList=document.getElementsByClassName("srcs");
 	      
        // 1. 获取需要的标签
        var ps = document.getElementById("ps");

        // 2. 动态创建li标签
        for(var i=0; i<allList.length; i++){
            // 2.1 创建li标签
            var li = document.createElement("li");
            ps.appendChild(li);

            // 2.2 创建img标签
            var img = document.createElement("img");
            img.src = "/"+allList[i].value;
          img.style.width="350px";
       
            li.appendChild(img);
        }

        // 3. 获取所有的li
        var allLis = ps.children;

        // 4. 求出屏幕的宽度和高度
        var screenW = document.documentElement.clientWidth - 250;
        var screenH = document.documentElement.clientHeight - 360;

        // 5. 遍历
        for(var j=0; j<allLis.length; j++){
            // 5.1 取出单个li标签
            var li = allLis[j];

            // 5.2 随机分布
            li.style.left = _.random(0, screenW) + 'px';
            li.style.top = _.random(0, screenH) + 'px';

            // 5.3 随机角度
            li.style.transform = 'rotate(' + _.random(0, 360) +'deg)';

            // 5.4 监听点击事件
            li.onclick = function () {
                for(var i = 0; i<allLis.length; i++){
                    allLis[i].className = '';
                }
                this.className = 'current';
            }
        }
    }
</script>
</body>
</html>