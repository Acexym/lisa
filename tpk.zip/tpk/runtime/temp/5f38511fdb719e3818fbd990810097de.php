<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:51:"E:\phpStudy2016\WWW\tpk\addons\message\message.html";i:1563858765;}*/ ?>
<script src="/static/addons/message/ckeditor5-build-classic/ckeditor.js"></script>
<div class="container">
    <form method="post" action="<?php echo addon_url('message://Index/save'); ?>">
        <input type="hidden" name="cid" value="<?php echo $cid; ?>">
        <div class="form-group">
            <label for="name">姓名</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="姓名">
        </div>
        <div class="form-group">
            <label for="name">手机</label>
            <input type="text" class="form-control" name="phone" id="phone" placeholder="手机">
        </div>
        <div class="form-group">
            <label for="name">留言内容</label>
            <textarea class="form-control" rows="3" name="content" id="content"></textarea>
        </div>
        <button type="submit" class="btn btn-default">留言</button>
    </form>
</div>
<script>
    ClassicEditor
        .create( document.querySelector( '#content' ) )
        .then( editor => {
        console.log( editor );
    } )
    .catch( error => {
        console.error( error );
    } );
</script>