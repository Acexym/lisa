<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\auth_group\setrule.html";i:1563430717;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>分配权限</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
    <div class="x-body">
        <form class="layui-form">
            <input type="hidden" name="id" value="<?php echo $authgroup['id']; ?>">
            <input type="hidden" name="setrule" value="1">
          <div class="layui-form-item">
              <label for="title" class="layui-form-label">
                  <span class="x-red">*</span>角色名称
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="title" name="title" value="<?php echo $authgroup['title']; ?>" required="" lay-verify="required|title"
                  autocomplete="off" class="layui-input" placeholder="请输入角色名称">
              </div>
          </div>
            <div class="layui-form-item">
                <label class="layui-form-label">选择权限</label>
                <button type="button" class="layui-btn layui-btn-xs layui-btn-primary" onclick="checkAll('#LAY-auth-tree-index')">全选</button>
                <button type="button" class="layui-btn layui-btn-xs layui-btn-primary" onclick="uncheckAll('#LAY-auth-tree-index')">全不选</button>
                <div class="layui-input-block">
                    <div id="LAY-auth-tree-index"></div>
                </div>
            </div>
          <!--<div class="layui-form-item">-->
                <!--<label class="layui-form-label"><span class="x-red">*</span>角色</label>-->
                <!--<div class="layui-input-block">-->
                    <!--<input type="checkbox" name="like1[write]" lay-skin="primary" title="超级管理员" checked="">-->
                    <!--<input type="checkbox" name="like1[read]" lay-skin="primary" title="编辑人员">-->
                    <!--<input type="checkbox" name="like1[write]" lay-skin="primary" title="宣传人员" checked="">-->
                <!--</div>-->
            <!--</div>-->
          <div class="layui-form-item">
              <label for="L_repass" class="layui-form-label">
              </label>
              <button  class="layui-btn" lay-filter="add" lay-submit="">
                  保存
              </button>
          </div>
      </form>
    </div>
    <script>
        layui.config({
            base: '/static/admin/lib/extends/',
        }).extend({
            authtree: 'authtree',
        });
        layui.use(['form','authtree','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer
              ,authtree= layui.authtree;
            $.ajax({
                url: '<?php echo url("admin/AuthGroup/getRules",["groupid"=>$authgroup['id']]); ?>',
                dataType: 'json',
                success: function(data){
                    var trees = data.data.trees;
                    // 如果后台返回的不是树结构，请使用 authtree.listConvert 转换
                    authtree.render('#LAY-auth-tree-index', trees, {
                        inputname: 'rules[]',
                        layfilter: 'lay-check-auth',
                        autowidth: true,
                    });
                }
            });
          //自定义验证规则
          form.verify({
              title: function(value){
              if(value.length < 3){
                return '账号至少得5个字符啊';
              }
            }
          });

          //监听提交
          form.on('submit(add)', function(data){
            //发异步，把数据提交给php
              $.post("<?php echo url('admin/AuthGroup/save'); ?>",data.field,function(res){
                if(res.code==1){
                    layer.alert(res.msg, {icon: 6},function () {
                        parent.location.reload();
                        // 获得frame索引
                        var index = parent.layer.getFrameIndex(window.name);
                        //关闭当前frame
                        parent.layer.close(index);
                    });
                }else{
                    layer.msg(res.msg);
                }
              },'json');
            return false;
          });
          
          
        });
        // 全选样例
        function checkAll(dst){
            layui.use(['jquery', 'layer', 'authtree'], function(){
                var layer = layui.layer;
                var authtree = layui.authtree;
                authtree.checkAll(dst);
            });
        }
        // 全不选样例
        function uncheckAll(dst){
            layui.use(['jquery', 'layer', 'authtree'], function(){
                var layer = layui.layer;
                var authtree = layui.authtree;
                authtree.uncheckAll(dst);
            });
        }
    </script>
  </body>

</html>