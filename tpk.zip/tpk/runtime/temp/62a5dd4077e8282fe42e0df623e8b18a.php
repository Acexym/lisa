<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\manager\add.html";i:1563112255;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>添加管理员</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
  </head>
  
  <body>
    <div class="x-body">
        <form class="layui-form" >
          <div class="layui-form-item">
              <label for="username" class="layui-form-label">
                  <span class="x-red">*</span>账号
              </label>
              <div class="layui-input-inline">
                  <input type="text" id="account" name="account" required="" lay-verify="required|account"
                  autocomplete="off" class="layui-input" placeholder="请输入管理员账号">
              </div>
          </div>

          <div class="layui-form-item">
              <label for="L_pass" class="layui-form-label">
                  <span class="x-red">*</span>密码
              </label>
              <div class="layui-input-inline">
                  <input type="password" id="passwd" name="passwd" required="" lay-verify="passwd"
                  autocomplete="off" class="layui-input" placeholder="请输入密码">
              </div>
          </div>
          <div class="layui-form-item">
              <label for="L_repass" class="layui-form-label">
                  <span class="x-red">*</span>确认密码
              </label>
              <div class="layui-input-inline">
                  <input type="password" id="repasswd" name="repasswd" required="" lay-verify="repasswd"
                  autocomplete="off" class="layui-input" placeholder="请输入确认密码">
              </div>
          </div>
            <div class="layui-form-item">
                <label class="layui-form-label">选择角色</label>
                <div class="layui-input-inline">
                    <select name="groupid" lay-verify="required">
                        <?php if(is_array($authgroup) || $authgroup instanceof \think\Collection || $authgroup instanceof \think\Paginator): $i = 0; $__LIST__ = $authgroup;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $vo['id']; ?>"><?php echo $vo['title']; ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </div>
            </div>
     
          <div class="layui-form-item">
              <label for="L_repass" class="layui-form-label">
              </label>
              <button  class="layui-btn" lay-filter="add" lay-submit="">
                  添加
              </button>
          </div>
      </form>
    </div>
    <script>
        layui.use(['form','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer;
        
          //自定义验证规则
          form.verify({
              account: function(value){
              if(value.length < 5){
                return '账号至少得5个字符啊';
              }
            }
            ,passwd: [/(.+){6,12}$/, '密码必须6到12位']
            ,repasswd: function(value){
                if($('#L_pass').val()!=$('#L_repass').val()){
                    return '两次密码不一致';
                }
            }
          });

//          监听提交
         form.on('submit(add)', function(data){
            //发异步，把数据提交给php
              $.post("<?php echo url('admin/Manager/save'); ?>",data.field,function(res){
                if(res.code==1){
                    layer.alert(res.msg, {icon: 6},function () {
                        parent.location.reload();
                        // 获得frame索引
                        var index = parent.layer.getFrameIndex(window.name);
                        //关闭当前frame
                        parent.layer.close(index);
                    });
                }else{
                    layer.msg(res.msg);
                }
              },'json');
            return false;
          });
          
          
        });
    </script>
  </body>

</html>