<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\database\backuplst.html";i:1563786106;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>数据表备份</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/common/js/jquery.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
    <div class="x-body">
      <xblock>
        <button class="layui-btn layui-btn-danger" onclick="backup('<?php echo $table; ?>')"><i class="layui-icon"></i>备份</button>
        <span class="x-right" style="line-height:40px">共有数据：<?php echo count($list); ?> 条</span>
      </xblock>
      <table class="layui-table"  lay-filter="mytable">
        <thead>
          <tr>
            <th lay-data="{field:'time', width:180}">备份时间</th>
            <th lay-data="{field:'engine'}">备份名称</th>
            <th lay-data="{field:'author', width:120}">文件大小</th>
            <th lay-data="{field:'collation', width:80}">类型</th>
        <th lay-data="{field:'caozuo', width:200}">操作</th>
        </thead>
        <tbody>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <tr>
            <td><?php echo date("Y/m/d H:i:s",$vo['time']); ?></td>
            <td><?php echo $vo['filename']; ?></td>
            <td><?php echo format_size($vo['size']); ?></td>
            <td><?php echo $vo['compress']; ?></td>
            <td class="td-manage">
              <a href="<?php echo url('admin/Database/download',['t'=>$table,'time'=>$vo['time']]); ?>" class="layui-btn layui-btn-normal layui-btn-xs">下载</a>
              <a href="javascript:;" onclick="restore('<?php echo $table; ?>','<?php echo $vo['time']; ?>')" class="layui-btn layui-btn-normal layui-btn-xs">还原</a>
              <a href="javascript:;" onclick="del('<?php echo $table; ?>','<?php echo $vo['time']; ?>')" class="layui-btn layui-btn-danger layui-btn-xs">删除</a>
            </td>
          </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
      </table>
    </div>
    <script>
      var table;
      var repairAll;
      layui.use('table', function(){
          table= layui.table;
          //转换静态表格
          table.init('mytable', {
              id:"mytable"
              ,height: 600 //设置高度
              ,limit:600
          });
      });

      //单表备份
      function backup(tablename){
        $.post("<?php echo url('admin/Database/dbbackup'); ?>",{t:tablename},function(res){
          layer.msg(res.msg,{time:1000},function () {
              location.reload();
          });
        },'json');
      }

      //数据还原
      function restore(tablename,time){
          $.post("<?php echo url('admin/Database/restore'); ?>",{t:tablename,time:time},function(res){
              layer.msg(res.msg,{time:1000},function () {
                  location.reload();
              });
          },'json');
      }
      //备份删除
      function del(tablename,time){
          $.post("<?php echo url('admin/Database/del'); ?>",{t:tablename,time:time},function(res){
              layer.msg(res.msg,{time:1000},function () {
                  location.reload();
              });
          },'json');
      }
      //备份删除
      // function downloads(tablename,time){
      //     $.post("<?php echo url('admin/Database/download'); ?>",{t:tablename,time:time},function(res){
      //         layer.msg(res.msg,{time:1000},function () {
      //             location.reload();
      //         });
      //     },'json');
      // }
    </script>

  </body>

</html>