<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\index\cate.html";i:1564040095;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
	</body>
</html>
