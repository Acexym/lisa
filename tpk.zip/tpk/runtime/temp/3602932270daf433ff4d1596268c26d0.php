<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:75:"E:\phpStudy2016\WWW\tpk\public/../application/admin\view\manager\index.html";i:1563613496;}*/ ?>
<!DOCTYPE html>
<html>
  
  <head>
    <meta charset="UTF-8">
    <title>管理员列表</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/admin/css/font.css">
    <link rel="stylesheet" href="/static/admin/css/xadmin.css">
    <script type="text/javascript" src="/static/common/js/jquery.min.js"></script>
    <script type="text/javascript" src="/static/admin/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/admin/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
      <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
      <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
    <div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">管理员管理</a>
        <a>
          <cite>管理员列表</cite></a>
      </span>
      <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
    </div>
    <div class="x-body">
      <xblock>
        <button class="layui-btn layui-btn-danger" onclick="delAll()"><i class="layui-icon"></i>批量删除</button>
        <button class="layui-btn" onclick="x_admin_show('添加管理员','<?php echo url("admin/Manager/add"); ?>',500,400)"><i class="layui-icon"></i>添加</button>
        <span class="x-right" style="line-height:40px">共有数据：<?php echo count($list); ?> 条</span>
      </xblock>
      <table class="layui-table"  lay-filter="mytable">
        <thead>
          <tr>
            <th lay-data="{type:'checkbox', width:60}">

            </th>
            <th lay-data="{field:'id', width:80}">ID</th>
            <th lay-data="{field:'accout'}">账号</th>
            <th lay-data="{field:'role', width:150}">角色</th>
            <th lay-data="{field:'create_time', width:180}">加入时间</th>
            <th lay-data="{field:'update_time', width:180}">更新时间</th>
            <th lay-data="{field:'status', width:150}">状态</th>
            <th lay-data="{field:'caozuo', width:200}">操作</th>
        </thead>
        <tbody>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <tr>
            <td>
              <div class="layui-unselect layui-form-checkbox" lay-skin="primary" data-id='2'><i class="layui-icon">&#xe605;</i></div>
            </td>
            <td><?php echo $vo['id']; ?></td>
            <td><?php echo $vo['account']; ?></td>
            <td><?php echo getgrouptitle($vo['id']); ?></td>
            <td><?php echo date("Y/m/d",$vo['create_time']); ?></td>
            <td><?php echo date("Y/m/d",$vo['update_time']); ?></td>
            <td class="td-status">
              <?php if($vo['status'] == '1'): ?>
              <span class="layui-btn layui-btn-normal layui-btn-mini">已启用</span>
              <?php else: ?>
              <span class="layui-btn layui-btn-danager layui-btn-mini">已停用</span>
              <?php endif; ?>
            </td>
            <td class="td-manage">
              <a onclick="member_stop(this,'<?php echo $vo['id']; ?>')" href="javascript:;"  title="启用">
                <i class="layui-icon">&#xe601;</i>
              </a>
              <a title="编辑"  onclick="x_admin_show('编辑','<?php echo url("admin/Manager/edit",["id"=>$vo['id']]); ?>',500,400)" href="javascript:;">
                <i class="layui-icon">&#xe642;</i>
              </a>
              <a title="删除" onclick="member_del(this,'<?php echo $vo['id']; ?>')" href="javascript:;">
                <i class="layui-icon">&#xe640;</i>
              </a>
            </td>
          </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
      </table>
    </div>
    <script>
      var table;
      layui.use('table', function(){
          table= layui.table;

          //转换静态表格
          table.init('mytable', {
              id:"mytable"
              ,height: 315 //设置高度
              ,limit: 1 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
              //支持所有基础参数
              ,page:{
                  count:<?php echo count($list); ?>
                  ,limit:10

              }
          });
      });

      /*用户-停用*/
      function member_stop(obj,id){
          layer.confirm('确认要停用吗？',function(index){
              $.post("<?php echo url('admin/Manager/setstatus'); ?>",{id:id},function(res){
                  layer.msg(res.msg,{time:1000},function(){
                      if(res.code==1){
                          location.reload();
                             if($(obj).attr('title')=='启用'){
                                 //发异步把用户状态进行更改
                                 $(obj).attr('title','停用')
                                 $(obj).find('i').html('&#xe62f;');
                            
                                 $(obj).parents("tr").find(".td-status").find('span').addClass('layui-btn-disabled').html('已停用');
                                 layer.msg('已停用!',{icon: 5,time:1000});
                            
                             }else{
                                 $(obj).attr('title','启用')
                                 $(obj).find('i').html('&#xe601;');
                            
                                 $(obj).parents("tr").find(".td-status").find('span').removeClass('layui-btn-disabled').html('已启用');
                                 layer.msg('已启用!',{icon: 5,time:1000});
                             }
                      }
                  });
              },'json');

              
          });
      }

      /*用户-删除*/
      function member_del(obj,id){
          layer.confirm('确认要删除吗？',function(index){
              //发异步删除数据
              $.post("<?php echo url('admin/Manager/delete'); ?>",{id:id},function(res){
                  layer.msg(res.msg,{time:1000},function(){
                      if(res.code==1){
                          $(obj).parents("tr").remove();
                      }
                  });
              },'json');

          });
      }



      function delAll (argument) {

       var checkStatus = table.checkStatus('mytable');
       var ids=new Array(),key;
        for(key in checkStatus.data){
            ids.push(checkStatus.data[key].id);
        }
        ids=ids.join(",");
        layer.confirm('确认要删除吗？',function(index){
            //捉到所有被选中的，发异步进行删除
            $.post("<?php echo url('admin/Manager/delete'); ?>",{id:ids},function(res){
                layer.msg(res.msg,{time:1000},function(){
                    if(res.code==1){
                        $(".layui-form-checked").not('.header').parents('tr').remove();
                    }
                });
            },'json');
        });
      }
    </script>

  </body>

</html>