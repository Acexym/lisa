<?php
//000000000000
 exit();?>
a:3:{s:8:"autoload";b:1;s:5:"hooks";a:3:{s:6:"gghook";a:1:{i:0;s:8:"guanggao";}s:11:"_initialize";a:1:{i:0;s:7:"message";}s:11:"messagehook";a:1:{i:0;s:7:"message";}}s:8:"fileflag";s:10:"config.php";}