<?php
//000000000000
 exit();?>
a:3:{s:6:"gghook";a:1:{i:0;s:25:"\addons\guanggao\Guanggao";}s:11:"_initialize";a:1:{i:0;s:23:"\addons\message\Message";}s:11:"messagehook";a:1:{i:0;s:23:"\addons\message\Message";}}