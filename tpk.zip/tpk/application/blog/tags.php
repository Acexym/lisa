<?php
return [
    'action_begin'=> [
        'app\\blog\\behavior\\Login',
    ],

]
?>