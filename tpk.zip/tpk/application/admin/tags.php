<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2018/11/6
 * Time: 22:39
 */
return [
    'app_end'=>[
        'app\\admin\\behavior\\Logs',
    ],

];