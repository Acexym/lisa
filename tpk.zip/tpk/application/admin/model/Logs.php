<?php

namespace app\admin\model;

use think\Model;

class Logs extends Model
{
    //
}
