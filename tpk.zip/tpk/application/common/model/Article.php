<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2018/6/6
 * Time: 22:57
 */

namespace app\common\model;

use think\Model;
class Article extends Model
{
	 public function getCidAttr($value)
    {
        $cate=Blogcate::where('cid',$value)->value("name");
        return $cate;
    }
}