<?php
/**
 * Created by PhpStorm.
 * User: yifeng
 * Date: 2018/6/6
 * Time: 22:57
 */

namespace app\common\model;

use think\Model;
class Picscate extends Model
{

}