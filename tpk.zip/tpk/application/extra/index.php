<?php
return [
    'hotnum'=>3,
];
?>