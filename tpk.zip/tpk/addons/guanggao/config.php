    <?php
    return array (
  'name' => 'guanggao',
  'title' => '插件测试',
  'description' => 'thinkph5插件测试',
  'status' => 0,
  'author' => 'byron sampson',
  'version' => '0.1',
  'menu' => 
  array (
  ),
);