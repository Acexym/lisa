    <?php
    return array (
  'name' => 'message',
  'title' => '在线留言',
  'description' => '在线留言插件',
  'status' => 0,
  'author' => 'ming',
  'version' => '1.0',
  'menu' => 
  array (
    'name' => '查看留言',
    'url' => '/addons/execute/message-index-lst.html',
    'type' => 0,
  ),
);